"""Auxiliary ReadLip losses corresponding to Eqs. 12, 15, 18, 19.

Encoders and preprocessors must be supplied as frozen, independently loaded
models: SyncNet-related embeddings; ArcFace for training; AV-HuBERT mouth
features for copy suppression. FaceNet should be reserved for evaluation.
"""
from dataclasses import dataclass
import torch
import torch.nn.functional as F

@dataclass
class GenerationWeights:
    semantic: float = 1e-5
    sync: float = 1e-3
    pixel: float = 1.0
    copy: float = 0.1
    id_suppression: float = 0.1
    gan: float = 0.01

def _cos_distance(a, b):
    return 1.0 - F.cosine_similarity(a, b, dim=-1)

def contrastive_sync_loss(audio_embed, original_video_embed,
                          cross_video_embed, temperature):
    """Eq.12; inputs are time-aligned [B,T,D] projected embeddings.

    Other timesteps within the same clip are negatives, as manuscript states.
    This implementation is a per-video InfoNCE over time positions.
    """
    if temperature <= 0:
        raise ValueError('temperature must be positive')
    def branch(visual):
        a = F.normalize(audio_embed, dim=-1)
        v = F.normalize(visual, dim=-1)
        logits = torch.bmm(a, v.transpose(1,2)) / temperature
        b,t,_ = logits.shape
        target = torch.arange(t, device=logits.device).expand(b,t)
        return F.cross_entropy(logits.reshape(b*t,t), target.reshape(-1))
    return branch(original_video_embed) + branch(cross_video_embed)

def identity_suppression_loss(generated_face_features, target_face_features,
                              driving_face_features, margin, valid=None):
    """Eq.15; ArcFace embeddings [B,T,D], references [B,D] or [B,T,D]."""
    if margin < 0:
        raise ValueError('margin must be nonnegative')
    def broadcast(ref):
        return ref[:,None,:] if ref.ndim == 2 else ref
    dt = _cos_distance(generated_face_features, broadcast(target_face_features))
    dd = _cos_distance(generated_face_features, broadcast(driving_face_features))
    return _masked_mean(F.relu(dt - dd + margin), valid)

def _masked_mean(values, mask):
    if mask is None:
        return values.mean()
    mask = mask.to(device=values.device, dtype=values.dtype)
    return (values * mask).sum() / mask.sum().clamp(min=1)

def copy_suppression_loss(generated_mouth_features, target_mouth_features,
                          reference_mouth_features, margin, threshold):
    """Eq.18: frozen lip-reader feature vectors [B,T,D]; reference [B,D]."""
    if margin < 0 or threshold < 0:
        raise ValueError('margin and threshold must be nonnegative')
    ref = (reference_mouth_features[:,None,:] if reference_mouth_features.ndim == 2
           else reference_mouth_features)
    d_gen_gt = (generated_mouth_features - target_mouth_features).abs().sum(-1)
    d_gen_ref = (generated_mouth_features - ref).abs().sum(-1)
    d_ref_gt = (ref - target_mouth_features).abs().sum(-1)
    valid = d_ref_gt > threshold
    return _masked_mean(F.relu(d_gen_gt - d_gen_ref + margin), valid)

def readlip_generator_loss(semantic, sync, pixel, copy, identity, gan,
                           weights=None):
    w = weights or GenerationWeights()
    return (w.semantic*semantic + w.sync*sync + w.pixel*pixel +
            w.copy*copy + w.id_suppression*identity + w.gan*gan)
