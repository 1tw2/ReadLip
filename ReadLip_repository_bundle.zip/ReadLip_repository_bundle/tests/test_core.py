import torch
import torch.nn as nn
import torch.nn.functional as F
from readlip.disentanglement import Disentangler, gradient_reverse
from readlip.losses import (contrastive_sync_loss, identity_suppression_loss,
                            copy_suppression_loss, readlip_generator_loss)

def test_grl():
    x = torch.tensor([2.0], requires_grad=True)
    gradient_reverse(x, 0.5).sum().backward()
    assert x.grad.item() == -0.5

def test_losses():
    a = torch.randn(2, 4, 8, requires_grad=True)
    o = torch.randn(2, 4, 8, requires_grad=True)
    c = torch.randn(2, 4, 8, requires_grad=True)
    loss = contrastive_sync_loss(a,o,c,0.07)
    loss.backward()
    assert torch.isfinite(loss) and a.grad is not None
    face = torch.randn(2,4,8, requires_grad=True)
    identity = identity_suppression_loss(face,torch.randn(2,8),torch.randn(2,8),0.1)
    mouth = copy_suppression_loss(torch.randn(2,4,8,requires_grad=True),
                                  torch.randn(2,4,8),torch.randn(2,8),0.2,0.1)
    assert torch.isfinite(identity) and torch.isfinite(mouth)
    assert torch.isfinite(readlip_generator_loss(loss,loss,loss,mouth,identity,loss))

def test_stage1_stage2():
    m = Disentangler(nn.Linear(5,6),nn.Linear(5,7),6,7,8,
                     nn.Linear(8,9),nn.Linear(8,3),nn.Linear(8,9),nn.Linear(8,3))
    x,y = torch.randn(2,5),torch.randn(2,5)
    ti,tj = torch.randint(0,9,(2,)),torch.randint(0,9,(2,))
    qi,qj = torch.randint(0,3,(2,)),torch.randint(0,3,(2,))
    a,_ = m.stage1_loss(x,ti,qi,F.cross_entropy)
    a.backward()
    m.zero_grad()
    m.freeze_recognition_heads()
    b = m.stage2_loss(x,y,ti,tj,qi,qj,F.cross_entropy)
    b.backward()
    assert torch.isfinite(a) and torch.isfinite(b)
    assert m.content_encoder.weight.grad is not None
