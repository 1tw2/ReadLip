"""ReadLip Stage I/II (equations 1--10 in the manuscript).

Adapters are deliberately required for Whisper ASR and speaker recognition:
the manuscript does not specify feature/token interfaces or checkpoint details.
Do not substitute dummy recognition targets for real transcripts/pseudo labels.
"""
from dataclasses import dataclass
import torch
from torch import nn
import torch.nn.functional as F

class _GRL(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, strength):
        ctx.strength = strength
        return x.view_as(x)
    @staticmethod
    def backward(ctx, grad):
        return -ctx.strength * grad, None

def gradient_reverse(x, strength=1.0):
    return _GRL.apply(x, float(strength))

@dataclass
class DisentangleWeights:
    direct: float = 1.0
    fuse: float = 1.0
    adv_speaker: float = 0.1
    adv_asr: float = 0.1
    orth: float = 0.01

class Disentangler(nn.Module):
    """Encode audio, learn factor separation, and recombine two samples.

    encoders: modules mapping acoustic inputs to feature tensors [B,T,D] or [B,D].
    Heads: recognition adapters whose outputs are logits; asr_loss(logits, labels)
    must handle Whisper decoder/token masking when supplied in the real system.
    The same feature shape is required across content/identity projections.
    """
    def __init__(self, content_encoder, speaker_encoder, content_dim,
                 speaker_dim, hidden_dim, asr_head, speaker_head,
                 asr_adv_head, speaker_adv_head):
        super().__init__()
        self.content_encoder = content_encoder
        self.speaker_encoder = speaker_encoder
        self.content_project = nn.Linear(content_dim, hidden_dim)
        self.speaker_project = nn.Linear(speaker_dim, hidden_dim)
        self.gate = nn.Sequential(nn.Linear(2 * hidden_dim, hidden_dim), nn.Sigmoid())
        self.asr_head, self.speaker_head = asr_head, speaker_head
        self.asr_adv_head, self.speaker_adv_head = asr_adv_head, speaker_adv_head

    def encode(self, audio):
        content = self.content_encoder(audio)
        speaker = self.speaker_encoder(audio)
        u = self.content_project(content)
        v = self.speaker_project(speaker)
        if u.shape != v.shape:
            raise ValueError(f'Projected content/speaker tensors must align: {u.shape} vs {v.shape}. '
                             'Add temporal pooling/upsampling in a dataset-specific adapter.')
        return content, speaker, u, v

    def fuse(self, u, v):
        g = self.gate(torch.cat([u, v], dim=-1))
        return g * u + (1 - g) * v

    @staticmethod
    def orth_loss(u, v):
        return F.cosine_similarity(u, v, dim=-1).square().mean()

    def stage1_loss(self, audio, transcript, speaker_ids, asr_loss,
                    weights=None, grl_strength=1.0):
        w = weights or DisentangleWeights()
        _, _, u, v = self.encode(audio)
        joint = self.fuse(u, v)
        direct_asr = asr_loss(self.asr_head(u), transcript)
        direct_spk = F.cross_entropy(self.speaker_head(v), speaker_ids)
        fused_asr = asr_loss(self.asr_head(joint), transcript)
        fused_spk = F.cross_entropy(self.speaker_head(joint), speaker_ids)
        adv_spk = F.cross_entropy(self.speaker_adv_head(gradient_reverse(u,grl_strength)), speaker_ids)
        adv_asr = asr_loss(self.asr_adv_head(gradient_reverse(v,grl_strength)), transcript)
        orth = self.orth_loss(u, v)
        total = (w.direct * (direct_asr + direct_spk)
                 + w.fuse * (fused_asr + fused_spk)
                 + w.adv_speaker * adv_spk + w.adv_asr * adv_asr
                 + w.orth * orth)
        return total, dict(direct_asr=direct_asr, direct_spk=direct_spk,
                           fuse_asr=fused_asr, fuse_spk=fused_spk,
                           adv_spk=adv_spk, adv_asr=adv_asr, orth=orth)

    def stage2_loss(self, audio_i, audio_j, transcript_i, transcript_j,
                    speaker_i, speaker_j, asr_loss):
        """Four (i,i), (i,j), (j,i), (j,j) terms per manuscript Eq. (10).

        Call freeze_recognition_heads() before stage-II training. Both inputs
        should represent different speaker identities for meaningful swaps.
        """
        _, _, ui, vi = self.encode(audio_i)
        _, _, uj, vj = self.encode(audio_j)
        samples = ((ui, vi, transcript_i, speaker_i),
                   (ui, vj, transcript_i, speaker_j),
                   (uj, vi, transcript_j, speaker_i),
                   (uj, vj, transcript_j, speaker_j))
        terms = [asr_loss(self.asr_head(self.fuse(u,v)), words) +
                 F.cross_entropy(self.speaker_head(self.fuse(u,v)), speaker)
                 for u,v,words,speaker in samples]
        return torch.stack(terms).mean()

    def freeze_recognition_heads(self):
        for head in (self.asr_head, self.speaker_head):
            head.eval()
            for p in head.parameters():
                p.requires_grad_(False)

    def content_features_for_generator(self, audio):
        """Paper Eq.(11) explicitly uses raw E_c(A), not the projected feature."""
        return self.content_encoder(audio)
