#!/usr/bin/env python3
"""Assemble full upstream TalkLip sources and separate ReadLip modules locally."""
import argparse
import shutil
import subprocess
from pathlib import Path

SRC = 'https://github.com/Sxjdwang/TalkLip.git'
ROOT = Path(__file__).resolve().parents[1]


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output', default='ReadLip', help='target directory (new)')
    p.add_argument('--talklip-path', help='use existing TalkLip checkout if GitHub is inaccessible')
    args=p.parse_args()
    out=Path(args.output).expanduser().resolve()
    if out.exists():
        raise SystemExit(f'Refusing to overwrite existing path: {out}')
    if args.talklip_path:
        baseline=Path(args.talklip_path).resolve()
        if not (baseline/'train.py').is_file() or not (baseline/'models').is_dir():
            raise SystemExit('Not a recognized TalkLip checkout (missing train.py or models/)')
        shutil.copytree(baseline, out, ignore=shutil.ignore_patterns('.git','*.pt','*.pth','*.ckpt','__pycache__'))
    else:
        subprocess.run(['git','clone','--depth','1',SRC,str(out)],check=True)
        # Detach from the upstream Git remote: future pushes target your new ReadLip repo.
        shutil.rmtree(out/'.git',ignore_errors=True)
    old_readme = out/'README.md'
    if old_readme.is_file():
        old_readme.rename(out/'TALKLIP_README.md')
    for name in ('readlip','tests'):
        shutil.copytree(ROOT/name,out/name,ignore=shutil.ignore_patterns('__pycache__'))
    for name in ('README_READLIP.md','README.md','.gitignore','pyproject.toml'):
        shutil.copy2(ROOT/name,out/name)
    print(f'Assembled: {out}')
    print('Verify with: cd "'+str(out)+'" && python -m pytest -q tests')
    print('Do not represent upstream train.py as ReadLip integrated: see README_READLIP.md')

if __name__=='__main__':
    main()
