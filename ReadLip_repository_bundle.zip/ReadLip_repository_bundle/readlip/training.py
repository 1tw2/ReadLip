"""ReadLip training helpers independent of the upstream TalkLip CLI.

These routines are model-agnostic and require the caller to supply real
recognition backbones, paired minibatches and the generator/visual modules.
They are NOT wired into upstream train.py automatically.
"""
from dataclasses import dataclass
from typing import Any, Callable
import torch
from torch.nn import functional as F
from .losses import (GenerationWeights, contrastive_sync_loss,
                     copy_suppression_loss, identity_suppression_loss,
                     readlip_generator_loss)


@dataclass
class TrainingBatch:
    audio: torch.Tensor
    driving_reference: torch.Tensor
    target_reference: torch.Tensor
    pose: torch.Tensor
    ground_truth: torch.Tensor
    transcript: Any


def generation_step(
    batch: TrainingBatch,
    content_encoder: Callable,
    encode_visual: Callable,
    generator: Callable,
    sync_embeddings: Callable,
    semantic_loss: Callable,
    mouth_embeddings: Callable,
    identity_embeddings: Callable,
    gan_generator_loss: Callable,
    *, temperature: float, identity_margin: float,
    copy_margin: float, copy_threshold: float,
    weights: GenerationWeights | None = None,
):
    """Compute paper Eq. (19) for matched and cross-ID branches.

    Adapters handle any cropping, audio/video alignment, pose preprocessing,
    teacher-forced text decoding, image detection, and checkpoint loading.
    Frozen evaluators MUST keep gradient paths to generated frame inputs.
    """
    content = content_encoder(batch.audio)
    match_vis = encode_visual(batch.driving_reference, batch.pose)
    cross_vis = encode_visual(batch.target_reference, batch.pose)
    matched = generator(content, match_vis)
    crossed = generator(content, cross_vis)

    audio_emb, original_emb = sync_embeddings(batch.audio, matched)
    _, crossed_emb = sync_embeddings(batch.audio, crossed)
    sync = contrastive_sync_loss(audio_emb, original_emb, crossed_emb, temperature)

    semantic = 0.5 * (
        semantic_loss(matched, batch.transcript)
        + semantic_loss(crossed, batch.transcript)
    )
    pixel = F.l1_loss(matched, batch.ground_truth)

    gen_mouth = mouth_embeddings(matched)
    tgt_mouth = mouth_embeddings(batch.ground_truth)
    ref_mouth = mouth_embeddings(batch.driving_reference)
    copy = copy_suppression_loss(gen_mouth, tgt_mouth, ref_mouth,
                                 copy_margin, copy_threshold)

    generated_id, target_id = identity_embeddings(crossed), identity_embeddings(batch.target_reference)
    driving_id = identity_embeddings(batch.driving_reference)
    identity = identity_suppression_loss(generated_id, target_id, driving_id,
                                         identity_margin)
    gan = gan_generator_loss(matched)
    total = readlip_generator_loss(semantic, sync, pixel, copy, identity, gan, weights)
    return total, dict(semantic=semantic, sync=sync, pixel=pixel, copy=copy,
                       identity=identity, gan=gan), (matched, crossed)
