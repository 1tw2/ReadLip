import torch
from readlip.training import TrainingBatch, generation_step


def test_step_has_gradients():
    b, t, d = 2, 3, 4
    x = torch.randn(b,t,d,requires_grad=True)
    batch = TrainingBatch(x,torch.randn(b,d),torch.randn(b,d),torch.zeros(b,t,d),torch.randn(b,t,d),torch.zeros(b))
    def visual(ref,pose): return ref.unsqueeze(1).expand(-1,t,-1)
    def generator(content,vis): return content + vis
    def sync(a,video):return a,video
    def sem(v,y):return v.square().mean()
    def mouth(z):return z
    def face(z):return z
    def gan(z):return z.square().mean()
    loss,parts,outs=generation_step(batch,lambda a:a, visual,generator,sync,sem,mouth,face,gan,
         temperature=.1,identity_margin=.2,copy_margin=.1,copy_threshold=.01)
    assert len(parts)==6
    assert outs[0].shape==(b,t,d)
    loss.backward()
    assert x.grad is not None
